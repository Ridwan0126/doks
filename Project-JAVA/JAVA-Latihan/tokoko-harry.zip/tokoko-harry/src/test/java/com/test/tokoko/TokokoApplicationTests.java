package com.test.tokoko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokokoApplicationTests {

	@Test
	void contextLoads() {
	}

}

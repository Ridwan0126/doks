package com.javaJWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.javaJWT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaJwtApplication.class, args);
	}

}

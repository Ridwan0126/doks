import Home from './Home'
import Sukses from './Sukses'

export { Home, Sukses }
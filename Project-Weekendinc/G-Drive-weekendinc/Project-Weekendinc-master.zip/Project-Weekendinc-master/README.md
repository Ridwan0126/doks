# TAKE HOME CHALLANGE

Weekendinc Take-Home-Challange, waktu (1 minggu).

File Design untuk tampilan (https://www.figma.com/file/BvgVv93I1r3NT8uHM4AWoh/WKND-Front-End-Recruitment-Test?node-id=0%3A1)

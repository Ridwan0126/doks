import Bitmap from "./Bitmap.png";
import Bitmap1 from "./Bitmap1.png";
import bg1 from "./bg1.png";
import logos from "./logos.png";
import animation from "./animation.png";
import Icon2 from "./icn2.png";
import Alpha from "./alpha.png";

export { Icon2, Bitmap, bg1, logos, Bitmap1, animation, Alpha };

import styled from "styled-components";

export default styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 170px;
  width: 100%;
  background-color: #ffff;
  color: black;
  margin: 20px 15px;
  margin-left: 15px;
`;
